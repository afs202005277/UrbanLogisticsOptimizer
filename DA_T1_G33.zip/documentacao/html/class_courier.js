var class_courier =
[
    [ "addPackage", "class_courier.html#a217e67aa6d64b876ba95b30b63b24d31", null ],
    [ "eraseDeliveries", "class_courier.html#a91ac1c0b3d65bd35ffbfc48fd6223cde", null ],
    [ "getLicensePlate", "class_courier.html#aaf567e6e21cf162dccdbbe4559b53dc0", null ],
    [ "getNumDeliveries", "class_courier.html#a0bc6f74614bbb98ba7744b34200cebea", null ],
    [ "getPesoAtual", "class_courier.html#a4103153dbd42386e204ffe0323aeef29", null ],
    [ "getPesoMax", "class_courier.html#acfbd945b71763112eb45c53a045daac9", null ],
    [ "getRatio", "class_courier.html#a725f7f44dfc0b181365c717c9fc98ded", null ],
    [ "getTransportFee", "class_courier.html#a51d97293fa5ec4103a7154b0b8ee8fb7", null ],
    [ "getVolAtual", "class_courier.html#aee52a7456d0b3b17778fd20b4ad561af", null ],
    [ "getVolMax", "class_courier.html#a37a53efa22a501b3bd20ccf0bce6ce11", null ],
    [ "isAvailable", "class_courier.html#aa91d20e5fd02b9c35197d6f35592cb6d", null ],
    [ "operator<", "class_courier.html#a2929467a2313454146e9e8860d655c70", null ],
    [ "operator>", "class_courier.html#a53ebebaa55bb7cd8e8f5feb34f33c0e3", null ],
    [ "removePackage", "class_courier.html#a6bd6c47b21269d5db73edb48797f85e7", null ],
    [ "setAvailable", "class_courier.html#a42854811c58d978986f818c5bf7a82e4", null ],
    [ "setDeliveries", "class_courier.html#ad36c71d4bf772c67c31b31f8789b2921", null ],
    [ "setPesoAtual", "class_courier.html#acdb66aad52d22af5d828f4501477864c", null ],
    [ "setVolAtual", "class_courier.html#a8a8c8e4b8bd826a06098603f8035aed1", null ]
];