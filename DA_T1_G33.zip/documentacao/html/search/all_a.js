var searchData=
[
  ['setavailable_0',['setAvailable',['../class_courier.html#a42854811c58d978986f818c5bf7a82e4',1,'Courier']]],
  ['setdeliveries_1',['setDeliveries',['../class_courier.html#ad36c71d4bf772c67c31b31f8789b2921',1,'Courier']]],
  ['setpesoatual_2',['setPesoAtual',['../class_courier.html#acdb66aad52d22af5d828f4501477864c',1,'Courier']]],
  ['setvolatual_3',['setVolAtual',['../class_courier.html#a8a8c8e4b8bd826a06098603f8035aed1',1,'Courier']]]
];
