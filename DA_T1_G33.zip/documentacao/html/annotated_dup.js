var annotated_dup =
[
    [ "Courier", "class_courier.html", "class_courier" ],
    [ "CourierGenerator", "class_courier_generator.html", "class_courier_generator" ],
    [ "ExpressTransport", "struct_express_transport.html", null ],
    [ "NormalPackageGenerator", "class_normal_package_generator.html", "class_normal_package_generator" ],
    [ "NormalTransport", "struct_normal_transport.html", null ],
    [ "WarehouseManagement", "class_warehouse_management.html", "class_warehouse_management" ]
];