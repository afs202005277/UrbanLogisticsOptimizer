var class_warehouse_management =
[
    [ "addNormalTransportPackages", "class_warehouse_management.html#aef46dbcc2ce2f97cd619d2b0f8e67f73", null ],
    [ "amountOfCouriersAvailable", "class_warehouse_management.html#abf524945abde6463fd33143b6ac17782", null ],
    [ "changeCourierAvailability", "class_warehouse_management.html#a96e54696f57f48b68731e0800cf6484e", null ],
    [ "distributePackages", "class_warehouse_management.html#a23ea98b3d7dc3209920fb4b7af60335b", null ],
    [ "endOfBusiness", "class_warehouse_management.html#aa885d63d98d34c54380e5b73de78f880", null ],
    [ "getOperationEfficiency", "class_warehouse_management.html#a613ab2e0d96de318f3cc30f9f0309440", null ],
    [ "getUsedCouriers", "class_warehouse_management.html#aafba64dd4c2d7fbc771ab7fbd9d8b93c", null ],
    [ "minAndMaxNumPackagesOfCouriers", "class_warehouse_management.html#aba007c2a08b58b90d3251a5a2710982a", null ],
    [ "numNormalTransportPackages", "class_warehouse_management.html#a36155d8ba12fa822b3385ec84dd76312", null ],
    [ "optimizeExpressTransports", "class_warehouse_management.html#a0839298dd11986f14a7a3cb73a90431b", null ],
    [ "optimizeNormalPackagesDistribution", "class_warehouse_management.html#a28c6558f11337360666b0d48b6736fcd", null ],
    [ "optimizeProfit", "class_warehouse_management.html#aab5a560734aaca25eb00681a6f8b98ac", null ]
];