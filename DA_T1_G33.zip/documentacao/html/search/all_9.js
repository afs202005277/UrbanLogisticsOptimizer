var searchData=
[
  ['removepackage_0',['removePackage',['../class_courier.html#a6bd6c47b21269d5db73edb48797f85e7',1,'Courier']]]
];
