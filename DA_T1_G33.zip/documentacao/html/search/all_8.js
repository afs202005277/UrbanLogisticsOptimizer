var searchData=
[
  ['operator_3c_0',['operator&lt;',['../class_courier.html#a2929467a2313454146e9e8860d655c70',1,'Courier']]],
  ['operator_3e_1',['operator&gt;',['../class_courier.html#a53ebebaa55bb7cd8e8f5feb34f33c0e3',1,'Courier']]],
  ['optimizeexpresstransports_2',['optimizeExpressTransports',['../class_warehouse_management.html#a11f297a1e28b286f91d72b0a712e5dd5',1,'WarehouseManagement']]],
  ['optimizenormalpackagesdistribution_3',['optimizeNormalPackagesDistribution',['../class_warehouse_management.html#a28c6558f11337360666b0d48b6736fcd',1,'WarehouseManagement']]],
  ['optimizeprofit_4',['optimizeProfit',['../class_warehouse_management.html#aab5a560734aaca25eb00681a6f8b98ac',1,'WarehouseManagement']]]
];
