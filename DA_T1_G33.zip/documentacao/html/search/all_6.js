var searchData=
[
  ['minandmaxnumpackagesofcouriers_0',['minAndMaxNumPackagesOfCouriers',['../class_warehouse_management.html#aba007c2a08b58b90d3251a5a2710982a',1,'WarehouseManagement']]]
];
