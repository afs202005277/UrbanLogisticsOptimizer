var searchData=
[
  ['isavailable_0',['isAvailable',['../class_courier.html#aa91d20e5fd02b9c35197d6f35592cb6d',1,'Courier']]]
];
